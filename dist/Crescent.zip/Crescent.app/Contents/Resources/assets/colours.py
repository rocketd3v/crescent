black = 0, 0, 0
yellow = 253, 233, 146
red = 255, 0, 0
blue = 0, 0, 128
gray = 144, 144, 144
white = 255, 255, 255
